import Navbar from "../components/Navbar.jsx";

function About() {
	return (
		<>
			<Navbar />
			<br />
			<br />
			<br />
			<h1>About!!!</h1>
		</>
	);
}

export default About;
