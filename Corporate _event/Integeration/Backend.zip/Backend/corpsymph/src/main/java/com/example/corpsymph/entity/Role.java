package com.example.corpsymph.entity;

public enum Role {
    USER,
    ADMIN
}
